<html>
<head>
    <title>Ahmad</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
</head>
<body style="background-color: #7FFFD4">
    <div class="ui container">
		<div class="ui segment" style="max-width: 800px; margin: 0 auto;">
			<h3 class="ui center aligned header""><font color="black">Create Table Schema</h3>
                                <div class="field">
                                        <div class="ui grid">
                                             <div class="sixteen wide column" style="text-align: right;">
                                                     <button class="ui button"<li><a href="index.php">Home</a></li></button>
                                             </div>
                                        </div>
                                </div>

 <div class="form">
    <form method="POST" action="schema.php">
      <p>

      <label for="dbname"><p style="font-weight: bold;">DB Endpoint Name</p> </label>


</div>
      <input type="text" name="dbname" id="dbname">
      </p>
      <p>
      <input type="submit" name="submit" id="submit" value="Submit">
      </p>
    </form>
 </body>
</html>


<?php
$dbhostname = $_POST['dbname'];
$username = "master";
$password = "lab-password";
$dbname = "prod_schema";

// checking connection
$conn = new mysqli($dbhostname, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// sql code to create table
$sql="create table `products` (
  `id` int(11) not null auto_increment,
  `name` varchar(45) not null,
  `quantity` varchar(45) not null,
  `price` varchar(45) not null,
  primary key (`id`),
  unique key `id_unique` (`id`))";
if ($conn->query($sql) === TRUE) {
    echo "Table products created successfully";
} else {
    echo "Error creating table: " . $sql . "</br>" . $conn->error;
}

echo "</br>";

//sql code add first record
$sql="insert into products (name, quantity, price) VALUES ('Keyboard', '17', '1800')";

if ($conn->query($sql) === TRUE) {
  echo "First record created successfully";
} else {
  echo "Error: " . $sql . "</br>" . $conn->error;
}

echo "</br>"; 

//sql code add second record
$sql="insert into products (name, quantity, price) VALUES ('Monitor', '11', '7900')";

if ($conn->query($sql) === TRUE) {
  echo "Second record created successfully";
} else {
  echo "Error: " . $sql . "</br>" . $conn->error;
}

$conn->close();
?>
